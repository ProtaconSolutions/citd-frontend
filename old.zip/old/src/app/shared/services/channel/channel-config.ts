export class ChannelConfig {
  url: string;
  hubName: string;
  channel: string;
}
