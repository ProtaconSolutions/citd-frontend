export enum JustifyContent {
  'flex-start' = 1,
  'flex-end',
  'center',
  'space-between',
  'space-around',
}
