export enum FlexDirection {
  'row' = 1,
  'row-reverse',
  'column',
  'column-reverse',
}
