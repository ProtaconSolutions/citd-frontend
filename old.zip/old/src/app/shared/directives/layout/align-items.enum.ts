export enum AlignItems {
  'flex-start' = 1,
  'flex-end',
  'center',
  'baseline',
  'stretch',
}
