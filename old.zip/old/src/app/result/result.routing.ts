import { Routes } from '@angular/router';
import { TaskRoutes } from "./task/task.routing";

export const ResultRoutes: Routes = [
  ...TaskRoutes
];